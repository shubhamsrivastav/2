package com.opentext.seleniumFramework.Utilities;

import java.util.Set;
import java.util.TreeSet;

public class test {

	public static void main(String[] args) {

		// OT question1
		String input = "88";

		Set<String> mySet = new TreeSet<>();
		for (int i = 0; i < input.length() - 1; i++) {
			mySet.add(Character.toString(input.charAt(i)).concat(Character.toString(input.charAt(i + 1))));
		}
		System.out.println(((TreeSet<String>) mySet).last());
	}

}
