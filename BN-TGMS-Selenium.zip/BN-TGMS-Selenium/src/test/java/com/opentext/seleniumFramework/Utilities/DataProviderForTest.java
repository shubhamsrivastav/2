package com.opentext.seleniumFramework.Utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DataProviderForTest {

	/*
	 * public static void main(String args[]) throws Exception { DataProviderForTest
	 * d = new DataProviderForTest();
	 * System.out.println(d.generateDataProviderLinkedHashMapForTest(System.
	 * getProperty("user.dir") + "/Testdata.xlsx", "Testdata", "Execution", "Yes"));
	 * }
	 */

	public Object[] generateDataProviderLinkedHashMapForTest(String filepath, String sheetName,
			String executionPickerColumn, String executionPickerValue) throws IOException {
		File file = new File(filepath);
		FileInputStream fis = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(fis);

		List<LinkedHashMap<String, String>> dataParameterArrayOfLinkedHashMap = new ArrayList<LinkedHashMap<String, String>>();
		ArrayList<String> columnHeadersFromExcelSheet = new ArrayList<String>();

		int columnIdForExecutionPicker = 0;

		try {

			XSSFSheet sheet = wb.getSheet(sheetName);
			DataFormatter formatter = new DataFormatter(Locale.US);
			int rowCount = sheet.getLastRowNum() - sheet.getFirstRowNum();
			int columnCount = (sheet.getRow(0).getLastCellNum() - sheet.getRow(0).getFirstCellNum()) - 1;
			System.out.println("******************* No of rows found=" + rowCount);
			System.out.println("******************* No of columns found=" + columnCount);

			Row headerRow = sheet.getRow(0);
			// populate headerArrayList to get all header names
			for (int headerCol = 0; headerCol <= columnCount; headerCol++) {
				columnHeadersFromExcelSheet.add(formatter.formatCellValue(headerRow.getCell(headerCol)));
				if (executionPickerColumn.equals(formatter.formatCellValue(headerRow.getCell(headerCol)))) {
					columnIdForExecutionPicker = headerCol;
					System.out.println("******************* Filtering testcases based on column "
							+ columnIdForExecutionPicker + " (" + executionPickerColumn + ") =" + executionPickerValue);
				}
			}

			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				Row dataRow = sheet.getRow(i);
				LinkedHashMap<String, String> rowDataFromExcelInLinkedHashMap = new LinkedHashMap<String, String>();
				if (dataRow == null) {
					// empty row, skip
				} else {
					if (formatter.formatCellValue(dataRow.getCell(columnIdForExecutionPicker))
							.equalsIgnoreCase(executionPickerValue)) {
						// iterate each column cell to insert to map
						for (int col = 0; col <= columnCount; col++) {
							rowDataFromExcelInLinkedHashMap.put(columnHeadersFromExcelSheet.get(col),
									formatter.formatCellValue(dataRow.getCell(col)).trim());
						}
						dataParameterArrayOfLinkedHashMap.add(rowDataFromExcelInLinkedHashMap);
					}
				}

			}

		} catch (Exception e) {
			if (wb != null) {
				wb.close();
			}
		}

		if (wb != null) {
			wb.close();
		}

		System.out
				.println("******************* Total testcases selected = " + dataParameterArrayOfLinkedHashMap.size());
		return dataParameterArrayOfLinkedHashMap.toArray();
	}

}
