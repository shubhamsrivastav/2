package com.opentext.seleniumFramework.BN_TGMS_Selenium;

import org.testng.annotations.Test;
import com.opentext.seleniumFramework.Utilities.DataProviderForTest;
import org.testng.annotations.DataProvider;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Properties;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import io.github.bonigarcia.wdm.WebDriverManager;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

public class OrchUITest {
    
    DataProviderForTest dataProvider = new DataProviderForTest();
    WebDriver driver;
    OrchUIMainPage objORCHLoginPage;
    public File testDetailsSummaryFile = new File(System.getProperty("user.dir") + "/TGXXSummaryReport.html");
    public static BufferedWriter bw;
    String originalWindow;

    @Test(dataProvider = "TestcaseInput")
    public void verifyTGXXTransactionInOrchUI(LinkedHashMap<String, String> inputTestData) throws InterruptedException, IOException {

	String currenttestcaseName = "Testcase_"+inputTestData.get("Sl.No")+" - TGXX Regression QA Node "+inputTestData.get("Node")+" - " + inputTestData.get("ItineraryName");
	String currenttestcaseFolder = System.getProperty("user.dir") + "/Screenshots/" + currenttestcaseName + "/";
	FileUtils.forceMkdir(new File(currenttestcaseFolder));
	FileReader reader=new FileReader("db.properties");
	Properties orchURLProperty=new Properties();  
	orchURLProperty.load(reader); 
	String orchURL=orchURLProperty.getProperty("Node"+inputTestData.get("Node")+"OrchURL");
	beforemethod(orchURL);
	
	try {
	    objORCHLoginPage.clickOnItineraryStartedAfterClearButton();
	    objORCHLoginPage.enterSenderAddress(inputTestData.get("Sender"));
	    objORCHLoginPage.enterReceiverAddress(inputTestData.get("Receiver"));
	    objORCHLoginPage.enterAprf(inputTestData.get("DocType"));
	    objORCHLoginPage.enterSnrf(inputTestData.get("ControlNo"));
	    objORCHLoginPage.clickOnItinerarysearchButton();
	    objORCHLoginPage.verifyStatusOfSearchResultCompleteHyperlink(inputTestData.get("Expected Itinerary Status"));
	    getCurrentScreenshot(driver, currenttestcaseFolder, "verifyStatusOfSearchResultCompleteHyperlink");
	    
	    objORCHLoginPage.clickOnSearchResultItineraryHyperlink();
	    objORCHLoginPage.switchToCustomTab("New Tab");
	    HashMap<String, String> itineraryResults = objORCHLoginPage.displayTableContents();
	    getCurrentScreenshot(driver, currenttestcaseFolder, "displayTableContents");
	
	    
	    String ActualItineraryStatus = itineraryResults.get("ItineraryStatus") +"-" +itineraryResults.get("ItineraryStatusDescription");
	    String StepListDetailsAndStatus = itineraryResults.get("StepDetailsInfo");
	    String StepExecutionMode=itineraryResults.get("StepExecutionMode");
		      
	    String testcaseheader= "<h2>"+ inputTestData.get("ItineraryName")+"</h2>";
            bw.write(testcaseheader);
	    
	    String tablehead= "<table class=\"cinereousTable\">\n"
			+ "<tr><thead>\n"
			+ "<th>Sl.No</th>\n"
			+ "<th>Itinerary Name</th>\n"
			+ "<th>Sender</th>\n"
			+ "<th>Receiver</th>\n"
			+ "<th>DocType</th>\n"
			+ "<th>ControlNumber</th>\n"
			+ "<th>Orchestration Link</th>\n"
			+ "<th>Expected Itinerary Status</th>\n"
			+ "<th>Actual Itinerary Status</th>\n"
			+ "<th>Itinerary Step Details</th>\n"
			+ "<th>Execution Mode</th>\n"
			+ "</thead></tr>\n"
			+ "";
		
	    bw.write(tablehead);
	    
	    String testcaseRow="<tr>\n"
                    	+ "<td>"+inputTestData.get("Sl.No")+"</td>\n"
                    	+ "<td>"+inputTestData.get("ItineraryName")+"</td>\n"
                    	+ "<td>"+inputTestData.get("Sender")+"</td>\n"
                    	+ "<td>"+inputTestData.get("Receiver")+"</td>\n"
                    	+ "<td>"+inputTestData.get("DocType")+"</td>\n"
                    	+ "<td>"+inputTestData.get("ControlNo")+"</td>\n"
                    	+ "<td><a href=\""+driver.getCurrentUrl()+"\" target=\"_blank#\">Click to view Itinerary</a></td>\n"
                    	+ "<td>"+inputTestData.get("Expected Itinerary Status")+"</td>\n"
                    	+ "<td>"+ActualItineraryStatus+"</td>\n"
                    	+ "<td>"+StepListDetailsAndStatus+"</td>\n"
                    	+ "<td>"+StepExecutionMode+"</td>\n"
                    	+ "</tr>";
	    
	    bw.write(testcaseRow);
	    
	} catch (Exception e) {
	    System.out.println("Failure observed due to " + e.getMessage());
	}
    }

    @BeforeSuite
    public void beforesuite() throws IOException {

	FileUtils.deleteDirectory(new File(System.getProperty("user.dir") + "/Screenshots"));
	WebDriverManager.chromedriver().setup();
	ChromeOptions options = new ChromeOptions();
	options.addArguments("start-maximized");
	options.addArguments("enable-automation");
	options.addArguments("--no-sandbox");
	options.addArguments("--disable-infobars");
	options.addArguments("--disable-dev-shm-usage");
	options.addArguments("--disable-browser-side-navigation");
	options.addArguments("--disable-gpu");
	driver = new ChromeDriver(options);
	driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	objORCHLoginPage = new OrchUIMainPage(driver);
	FileUtils.forceMkdir(new File(System.getProperty("user.dir") + "/Screenshots"));
	
	bw = new BufferedWriter(new FileWriter(testDetailsSummaryFile));
	
	String cssStyle="table.cinereousTable {\n"
		+ "  font-family: Arial, Helvetica, sans-serif;\n"
		+ "  border: 6px solid #776A5D;\n"
		+ "  background-color: #DFF2FF;\n"
		+ "  width: 100%;\n"
		+ "  text-align: left;\n"
		+ "}\n"
		+ "table.cinereousTable td, table.cinereousTable th {\n"
		+ "  border: 1px solid #010107;\n"
		+ "  padding: 4px 4px;\n"
		+ "}\n"
		+ "table.cinereousTable tbody td {\n"
		+ "  font-size: 13px;\n"
		+ "}\n"
		+ "table.cinereousTable tr:nth-child(even) {\n"
		+ "  background: #FFFFFF;\n"
		+ "}\n"
		+ "table.cinereousTable thead {\n"
		+ "  background: #0F6B96;\n"
		+ "  background: -moz-linear-gradient(top, #4b90b0 0%, #2779a0 66%, #0F6B96 100%);\n"
		+ "  background: -webkit-linear-gradient(top, #4b90b0 0%, #2779a0 66%, #0F6B96 100%);\n"
		+ "  background: linear-gradient(to bottom, #4b90b0 0%, #2779a0 66%, #0F6B96 100%);\n"
		+ "}\n"
		+ "table.cinereousTable thead th {\n"
		+ "  font-size: 17px;\n"
		+ "  font-weight: bold;\n"
		+ "  color: #EEF0EB;\n"
		+ "  text-align: center;\n"
		+ "}\n"
		+ "table.cinereousTable tfoot {\n"
		+ "  font-size: 16px;\n"
		+ "  font-weight: bold;\n"
		+ "  color: #F0F0F0;\n"
		+ "  background: #948473;\n"
		+ "  background: -moz-linear-gradient(top, #afa396 0%, #9e9081 66%, #948473 100%);\n"
		+ "  background: -webkit-linear-gradient(top, #afa396 0%, #9e9081 66%, #948473 100%);\n"
		+ "  background: linear-gradient(to bottom, #afa396 0%, #9e9081 66%, #948473 100%);\n"
		+ "}\n"
		+ "table.cinereousTable tfoot td {\n"
		+ "  font-size: 16px;\n"
		+ "}";
	
	String htmlstartTemplate="<html>\n"
		+ "<body>\n"
		+ "<style>"+ cssStyle + "</style>"
		+ "<h1>TGXX REGRESSION SUMMARY</h1>\n";
		
	bw.write(htmlstartTemplate);

    }

    @AfterSuite
    public void aftersuite() throws InterruptedException, IOException {
	driver.quit();
	if (bw != null) {
		bw.write("</body></html>");
		bw.close();
	}
    }

    
    public void beforemethod(String orchURL) throws InterruptedException, IOException {
	driver.navigate().to(orchURL);
	originalWindow=driver.getWindowHandle();
	Thread.sleep(1000);
	
    }
    
    @AfterMethod
    public void aftermethod() throws IOException {
	driver.close();
	driver.switchTo().window(originalWindow);
	bw.write("</table>");
    }

    @DataProvider(name = "TestcaseInput")
    public Object[] setUpTestData() throws IOException {
	return dataProvider.generateDataProviderLinkedHashMapForTest(System.getProperty("user.dir") + "/Testdata.xlsx", "TGXXTestdata", "Execution", "Yes");
    }

    public String getCurrentScreenshot(WebDriver driver, String screenshotPathForCurrentTestcase, String stepName) throws IOException {
	Screenshot screenshot = new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);
	String screenshotFileNameToGenerate = screenshotPathForCurrentTestcase + stepName.replaceAll("[^a-zA-Z0-9]", "_") + "_" + getCurrentTimeStampinGMT().replace(' ', '_').replace(':', '_') + ".jpg";
	ImageIO.write(screenshot.getImage(), "jpg", new File(screenshotFileNameToGenerate));
	System.out.println("Capture ScreenShot for step: " + stepName + "FilePath: " + screenshotFileNameToGenerate);
	return screenshotFileNameToGenerate;
    }

    public String getCurrentTimeStampinGMT() {
	SimpleDateFormat gmtDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	gmtDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
	return gmtDateFormat.format(new Date());
    }

}
