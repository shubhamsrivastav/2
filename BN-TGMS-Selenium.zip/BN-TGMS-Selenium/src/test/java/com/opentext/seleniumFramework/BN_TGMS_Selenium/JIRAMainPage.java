package com.opentext.seleniumFramework.BN_TGMS_Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class JIRAMainPage {
	WebDriver driver;
	Actions action;

	@FindBy(xpath = "//a[@id='create_link']")
	WebElement hrefCreateLink;

	@FindBy(id = "summary")
	WebElement inputTextAreaSummary;

	@FindBy(xpath = "//textarea[@id='components-textarea']")
	WebElement inputTextAreaComponents;

	@FindBy(xpath = "//h2[@title='Create Issue']")
	WebElement h2TitleCreateIssue;

	@FindBy(id = "versions-textarea")
	WebElement inputTextAreaAffectsVersion;

	@FindBy(xpath = "//parent::label[text()='Affects build']/following-sibling::input[@type='text']")
	WebElement inputTextAreaAffectsBuild;

	@FindBy(id = "assign-to-me-trigger")
	WebElement assignee;

	@FindBy(xpath = "//parent::label[text()='Team']/following-sibling::select")
	WebElement team;

	@FindBy(xpath = "//label[text()='Environment']/..//nav/..//a[text()='Text']")
	WebElement environmentTextHyperlink;

	@FindBy(xpath = "//textarea[@id='environment']")
	WebElement environmentTextArea;

	@FindBy(xpath = "//label[text()='Description']/..//nav/..//a[text()='Text']")
	WebElement descriptionTextHyperlink;

	@FindBy(xpath = "//textarea[@id='description']")
	WebElement descriptionTextArea;

	@FindBy(xpath = "//label[text()='Release Timebox']/..//select")
	WebElement releaseTimebox;

	@FindBy(xpath = "//label[text()='Billing Project']/..//select")
	WebElement billingProject;

	@FindBy(xpath = "//label[text()='Original Estimate']/..//input[@id='timetracking_originalestimate']")
	WebElement originalEstimateinHours;

	@FindBy(id = "create-issue-submit")
	WebElement createJiraSubmitButton;

	@FindBy(id = "advanced-search")
	WebElement advancedSearch;

	@FindBy(xpath = "//a[contains(text(),'XTGMS-')]")
	WebElement jiraId;

	@FindBy(xpath = "//a[@id='action_id_4']")
	WebElement startProgressButton;

	public JIRAMainPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		action = new Actions(driver);
	}

	public void clickOnCreateLink() {
		hrefCreateLink.click();
	}

	public void typeInputTextAreaSummary(String summary) {
		inputTextAreaSummary.sendKeys(summary);
	}

	public void typeInputTextAreaComponents(String component) {
		inputTextAreaComponents.sendKeys(component);
		action.moveToElement(h2TitleCreateIssue).click().build().perform();
	}

	public void typeInputTextAreaAffectsVersion(String affectsVersion) {
		inputTextAreaAffectsVersion.sendKeys(affectsVersion);
		action.moveToElement(h2TitleCreateIssue).click().build().perform();
	}

	public void typeInputTextAreaAffectsBuild(String affectedBuildVersion) {
		inputTextAreaAffectsBuild.sendKeys(affectedBuildVersion);
		action.moveToElement(h2TitleCreateIssue).click().build().perform();
	}

	public void clickOnAssignToMe() {
		assignee.click();
	}

	public void selectTeamName(String teamName) {
		Select teamSelect = new Select(team);
		teamSelect.selectByVisibleText(teamName);
	}

	public void clickOnEnvironmentTextHyperlink() {
		environmentTextHyperlink.click();
	}

	public void typeTextEnvironment(String environment) {
		environmentTextArea.sendKeys(environment.toUpperCase());
		action.moveToElement(h2TitleCreateIssue).click().build().perform();
	}

	public void clickOnDescriptionTextHyperlink() {
		descriptionTextHyperlink.click();
	}

	public void typeTextDescription(String description) {
		descriptionTextArea.sendKeys(description);
		action.moveToElement(h2TitleCreateIssue).click().build().perform();
	}

	public void selectReleaseTimebox(String currentRelease) {
		Select releaseTimeboxSelect = new Select(releaseTimebox);
		releaseTimeboxSelect.selectByVisibleText(currentRelease);
	}

	public void selectBillingProject(String nextRelease) {
		Select billingProjectSelect = new Select(billingProject);
		billingProjectSelect.selectByVisibleText(nextRelease);
	}

	public void typeOriginalEstimateinHours(String estimatedEffortInHours) {
		originalEstimateinHours.sendKeys(estimatedEffortInHours);
	}

	public void clickOnCreateJiraSubmitButton() {
		createJiraSubmitButton.click();
	}

	public void searchCurrentJiraTaskFromOpenIssues(String jiraSummary) {
		advancedSearch.clear();
		advancedSearch.sendKeys("summary ~\"" + jiraSummary + "\" order by key desc", Keys.ENTER);
	}

	public void clickOnJiraId() {
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		action.moveToElement(jiraId).click().build().perform();
	}

	public void clickOnStartProgressButton() {
		startProgressButton.click();
		try {
			Thread.sleep(60000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
