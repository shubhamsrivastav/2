package com.opentext.seleniumFramework.BN_TGMS_Selenium;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class OrchUIMainPage {
	WebDriver driver;
	Actions action;

	@FindBy(xpath = "//button/following::span[@id='calAfterField']/../button[contains(@onclick,'calAfterField')]")
	WebElement itineraryStartedAfterClearButton;

	@FindBy(id = "sender")
	WebElement senderTextbox;

	@FindBy(id = "receiver")
	WebElement receiverTextbox;

	@FindBy(id = "aprf")
	WebElement aprfTextbox;

	@FindBy(id = "snrf")
	WebElement snrfTextbox;

	@FindBy(id = "search")
	WebElement searchButton;

	@FindBy(xpath = "//tbody[@id='itinDataTable_data']//a[contains(@name,'statusLink')]")
	WebElement searchResultCompleteHyperlink;

	@FindBy(xpath = "//tbody[@id='itinDataTable_data']//a[contains(@href,'process.xhtml')]")
	WebElement searchResultItineraryHyperlink;

	@FindBys(@FindBy(xpath = "//table/tbody[@id='mainTabView:stepDataTable_data']/tr"))
	List<WebElement> resultStepDataTableRows;

	@FindBys(@FindBy(xpath = "//table/tbody[@id='mainTabView:stepDataTable_data']/tr[1]/td"))
	List<WebElement> resultStepDataTableColumn;

	@FindBy(css = "#mainTabView\\:itinDetailsStatusPanelGrid > tbody > tr:nth-child(2) > td:nth-child(2) > span")
	WebElement statusInformationTabStatus;
	
	@FindBy(css = "#mainTabView\\:itinDetailsStatusPanelGrid > tbody > tr:nth-child(2) > td:nth-child(4) > span")
	WebElement statusInformationTabStatusDescription;
	
	
	
	public OrchUIMainPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		action = new Actions(driver);
	}

	public void clickOnItineraryStartedAfterClearButton() {
		itineraryStartedAfterClearButton.click();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void enterSenderAddress(String sender) {
		senderTextbox.sendKeys(sender);
	}

	public void enterReceiverAddress(String receiver) {
		receiverTextbox.sendKeys(receiver);
	}

	public void enterAprf(String aprf) {
		aprfTextbox.sendKeys(aprf);
	}

	public void enterSnrf(String snrf) {
		snrfTextbox.sendKeys(snrf);
	}

	public void clickOnItinerarysearchButton() {
		searchButton.click();
	}

	public void verifyStatusOfSearchResultCompleteHyperlink(String expectedStatus) {
		Assert.assertEquals(searchResultCompleteHyperlink.getText(), expectedStatus);
	}

	public void clickOnSearchResultItineraryHyperlink() {
		searchResultItineraryHyperlink.click();
	}

	public void switchToCustomTab(String tabName) {
		ArrayList<String> currentTabs = new ArrayList<String>(driver.getWindowHandles());
		if (tabName.toUpperCase().contains("NEW")) {
			driver.switchTo().window(currentTabs.get(1));
		} else {
			driver.switchTo().window(currentTabs.get(0));
		}

	}

	public HashMap<String, String> displayTableContents() {
		System.out.println("Result Step Table has" + resultStepDataTableRows.size() + " rows & "
				+ resultStepDataTableColumn.size() + " columns");
		
		LinkedHashMap<String, ArrayList<String>> linkedHashMapForItineraryLineageInformation= new LinkedHashMap<String, ArrayList<String>>();
		LinkedHashMap<String, ArrayList<String>> arrayListForListofServiceStepsExecutedForItineraryInstance= new LinkedHashMap<String, ArrayList<String>>();
		HashMap<String,String> displayTableContentsMap= new LinkedHashMap<String, String>();
		
		for (int row = 1; row <= 1; row++) {
			ArrayList<String> stepResultDetails= new ArrayList<>();
			for (int column = 1; column < resultStepDataTableColumn.size(); column++) {
				if (column==1) {
					stepResultDetails.add(driver.findElement(By.xpath("//table[@role='treegrid']/tbody/tr[" + row + "]/td[" + column + "]/div/span[2]")).getText().toString().trim());
				} else {
					stepResultDetails.add(driver.findElement(By.xpath("//table[@role='treegrid']/tbody/tr[" + row + "]/td[" + column + "]/div/span")).getText().toString().trim());
				}
				
			}
			linkedHashMapForItineraryLineageInformation.put("ItineraryLineageInformationList", stepResultDetails);
			System.out.println(stepResultDetails.toString());
			//stepResultDetails.clear();
		}
		
		System.out.println("**************	ITINERARY STATUS\n"+linkedHashMapForItineraryLineageInformation.toString());
		
		
		for (int row = 1; row <= resultStepDataTableRows.size(); row++) {
			ArrayList<String> stepResultDetails= new ArrayList<>();
			for (int column = 1; column <= resultStepDataTableColumn.size(); column++) {
				stepResultDetails.add(driver.findElement(By.xpath("//table/tbody[@id='mainTabView:stepDataTable_data']/tr[" + row + "]/td[" + column + "]/div/span")).getText().toString().trim());
				
			}
			arrayListForListofServiceStepsExecutedForItineraryInstance.put(stepResultDetails.get(3), stepResultDetails);
			System.out.println(stepResultDetails.toString());
			//stepResultDetails.clear();
		}
		
		System.out.println("**************	STEP STATUS\n"+arrayListForListofServiceStepsExecutedForItineraryInstance.toString());
		
		System.out.println("Status="+ statusInformationTabStatus.getText().toString().trim());
		System.out.println("Status Description="+ statusInformationTabStatusDescription.getText().toString().trim());
		
		displayTableContentsMap.put("ItineraryStatus", statusInformationTabStatus.getText().toString().trim());
		displayTableContentsMap.put("ItineraryStatusDescription", statusInformationTabStatusDescription.getText().toString().trim());
		String stepDetailsInfo="<ol>";
		for (String stepname : arrayListForListofServiceStepsExecutedForItineraryInstance.keySet()) {
		    stepDetailsInfo+="<li>"+stepname.trim()+" is "+arrayListForListofServiceStepsExecutedForItineraryInstance.get(stepname).get(4).trim()+" which took "+arrayListForListofServiceStepsExecutedForItineraryInstance.get(stepname).get(10).trim()+", executed in "+arrayListForListofServiceStepsExecutedForItineraryInstance.get(stepname).get(11).trim()+"mode. </li>" ;
		}
		stepDetailsInfo+="</ol>";
		displayTableContentsMap.put("StepDetailsInfo", stepDetailsInfo);
		displayTableContentsMap.put("StepExecutionMode",linkedHashMapForItineraryLineageInformation.get("ItineraryLineageInformationList").get(7).trim());
		
		
		
		return displayTableContentsMap;
	
	}

}
