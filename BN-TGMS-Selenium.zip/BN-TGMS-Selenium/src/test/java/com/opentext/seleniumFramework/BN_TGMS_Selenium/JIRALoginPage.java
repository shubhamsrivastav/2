package com.opentext.seleniumFramework.BN_TGMS_Selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class JIRALoginPage {
	WebDriver driver;

	@FindBy(id = "login-form-username")
	WebElement userloginName;

	@FindBy(id = "login-form-password")
	WebElement userloginPassword;

	@FindBy(id = "login-form-submit")
	WebElement userloginSubmitButton;

	public JIRALoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void enterUserloginName(String username) {
		userloginName.sendKeys(username);
	}

	public void enterUserloginPassword(String password) {
		userloginPassword.sendKeys(password);
	}

	public void clickOnLogInButton() {
		userloginSubmitButton.click();
	}

}
