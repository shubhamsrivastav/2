package com.opentext.seleniumFramework.BN_TGMS_Selenium;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.opentext.seleniumFramework.Utilities.DataProviderForTest;
import org.testng.annotations.DataProvider;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class JiraTest {
	DataProviderForTest dataProvider = new DataProviderForTest();
	String webDriverPath = System.getProperty("user.dir") + "/SeleniumDrivers/chromedriver.exe";
	WebDriver driver;
	JIRALoginPage objJIRALoginPage;
	JIRAMainPage objJIRAMainPage;

	@Test(dataProvider = "TestcaseInput")
	public void loginToJIRA(LinkedHashMap<String, String> inputTestData) throws InterruptedException {
		driver.get("https://jira.opentext.com/secure/Dashboard.jspa?selectPageId=88939");

		// Create Jira
		objJIRAMainPage.clickOnCreateLink();

		Thread.sleep(10000);

		objJIRAMainPage.typeInputTextAreaSummary(inputTestData.get("Jira Summary"));
		objJIRAMainPage.typeInputTextAreaComponents(inputTestData.get("Components"));
		objJIRAMainPage.typeInputTextAreaAffectsVersion(inputTestData.get("Affects Version"));
		objJIRAMainPage.typeInputTextAreaAffectsBuild(inputTestData.get("Affects Build"));
		objJIRAMainPage.clickOnAssignToMe();
		objJIRAMainPage.selectTeamName(inputTestData.get("Team Name"));
		objJIRAMainPage.clickOnEnvironmentTextHyperlink();
		objJIRAMainPage.typeTextEnvironment(inputTestData.get("Environment"));
		objJIRAMainPage.clickOnDescriptionTextHyperlink();
		objJIRAMainPage.typeTextDescription(inputTestData.get("Description"));
		objJIRAMainPage.selectReleaseTimebox(inputTestData.get("Release Timebox"));
		objJIRAMainPage.selectBillingProject(inputTestData.get("Billing Project"));
		objJIRAMainPage.typeOriginalEstimateinHours(inputTestData.get("Original Estimate"));
		objJIRAMainPage.clickOnCreateJiraSubmitButton();

		// Changing status to In Progress
		driver.get("https://jira.opentext.com/issues/?filter=-1");
		objJIRAMainPage.searchCurrentJiraTaskFromOpenIssues(inputTestData.get("Jira Summary"));
		objJIRAMainPage.clickOnJiraId();
		objJIRAMainPage.clickOnStartProgressButton();

	}

	@BeforeSuite
	public void beforesuite() {
		System.setProperty("webdriver.chrome.driver", webDriverPath);

		DesiredCapabilities dc = new DesiredCapabilities();
		dc.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
		

		driver = new ChromeDriver(dc);
		driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);

		driver.get("https://jira.opentext.com/login.jsp");

		objJIRALoginPage = new JIRALoginPage(driver);
		objJIRAMainPage = new JIRAMainPage(driver);

		objJIRALoginPage.enterUserloginName("ssrivastava");
		objJIRALoginPage.enterUserloginPassword("TaylorSwift@13");
		objJIRALoginPage.clickOnLogInButton();
	}

	@AfterSuite
	public void aftersuite() throws InterruptedException {
		driver.quit();
	}

	@DataProvider(name = "TestcaseInput")
	public Object[] setUpTestData() throws IOException {
		return dataProvider.generateDataProviderLinkedHashMapForTest(System.getProperty("user.dir") + "/Testdata.xlsx",
				"Testdata", "Execution", "Yes");
	}

}
