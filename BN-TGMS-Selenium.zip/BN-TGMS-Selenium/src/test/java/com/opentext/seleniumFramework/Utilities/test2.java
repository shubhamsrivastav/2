package com.opentext.seleniumFramework.Utilities;

public class test2 {

	public static void main(String[] args) {
		
		//OT question2
		int a[] = { 51, 71, 17, 42 };
		// int a[]= {51,32,43};
		getsum(1001);

		int returnsum = -1;

		for (int i = 0; i < a.length; i++) {
			for (int j = i + 1; j < a.length; j++) {
				if (getsum(a[i]) == getsum(a[j]) && returnsum < (a[i] + a[j])) {
					returnsum = a[i] + a[j];
				}
			}
		}
		System.out.println(returnsum);
	}

	public static int getsum(int n) {
		int sum = 0;
		while (n > 0) {
			int currentdigit = n % 10;
			sum = sum + currentdigit;
			n = n / 10;
		}
		
		return sum;
	}

}
